package demo;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp;
import org.apache.hadoop.hbase.filter.FilterList;
import org.apache.hadoop.hbase.filter.FilterList.Operator;
import org.apache.hadoop.hbase.filter.PrefixFilter;
import org.apache.hadoop.hbase.filter.RowFilter;
import org.apache.hadoop.hbase.filter.SubstringComparator;
import org.apache.hadoop.hbase.util.Bytes;

public class Assignment192 {
	public static void main(String[] args) throws IOException, InterruptedException {
		Configuration conf = HBaseConfiguration.create();
		
		System.out.println("Creating HTable instance to 'customer'...");
		HTable table = new HTable(conf, "customer");
		
		System.out.println("Creating scan object...");
		Scan scan = new Scan();
		System.out.println("Narrowing down the result to detail column family...");
		scan.addFamily(Bytes.toBytes("detail"));

		System.out.println("Adding row filter on scan object...");
		
		FilterList fList = new FilterList(Operator.MUST_PASS_ONE);
		fList.addFilter(new RowFilter(CompareOp.EQUAL, new SubstringComparator("location")));
		fList.addFilter(new SingleColumnValueFilter(Bytes.toBytes("AUS")));
		scan.setFilter(fList);
				
		System.out.println("Getting a result scanner object...");
		ResultScanner rs = table.getScanner(scan);
		
		for (Result r : rs) {
			System.out.println("Result: " + r);
		}
		
		System.out.println("Closing Scanner instance...");
		rs.close();
	}
}
